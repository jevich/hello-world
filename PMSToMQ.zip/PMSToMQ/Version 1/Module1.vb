Option Explicit On 
'****************************************************************
'PMStoMQ -> This program loads messages from the root PMS inbound 
'           directory into MQ series which are processed at a later
'           time by a Siebel MQ receiver. 
'
'           The parameters are specified by the PMStoMQ.xml file
'               Queue Manager Name : /PMS/QueueMgrName
'               PA File Queue      : /PMS/PAQueueName
'               PS File Queue      : /PMS/PSQueueName
'               Root PMS FTP folder : /PMS/RootDirectory
'               ArchiveDirectory   : /PMS/ArchiveDirectory
'               BadDirectory : /PMS/BadDirectory
'               LogDirectory   : /PMS/LogDirectory
'               Position of the filetype in header record : /PMS/FileTypeIndPos
'****************************************************************
Imports System.IO
Imports Microsoft.VisualBasic.FileSystem
Imports IBM.WMQAX
Imports IBM.WMQ.MQC 'Added reference to AMQMDNET.DLL which is in MQ_ROOT\BIN
Module Module1
    Dim sRootDirectory As String
    Dim sArchiveDirectory As String
    Dim sDWArchiveDirectory As String
    Dim sBadDirectory As String
    Dim sLogDirectory As String
    Dim sMQMgrName As String
    Dim sPAQueueName As String
    Dim sPSQueuename As String
    Dim sLogFileName As String
    Dim dLastModified As Date
    Dim aFileNames() As String
    Dim aFilePaths() As String
    Dim iPosFileType As String
    Dim bInMQProcess As Boolean
    Dim iFileCount As Int32
    Dim aSkipDirs() As String
    Dim aLoadIntoMystique() As String
    Dim aArchiveToDW() As String
    Dim bValidHeader As Boolean
    Dim bValidFooter As Boolean

    Sub Main()

        Dim iCounter As Int32
        Dim sPath As String
        Dim sFileName As String
        Dim sFileData As String
        Dim sFileType As String
        Dim sMQError As String
        Dim bLoadToMystique As Boolean
        Dim bArchiveToDW As Boolean
        Dim sMARSHACD As String

        bArchiveToDW = False
        bLoadToMystique = False
        sMQError = ""
        iFileCount = 0

        sLogFileName = ".\PMSToMQ.log"
        'Read the parameters from the XML ini file
        Try
            ReadParameters()

            'Search the Root directory for incoming files
            SearchDirectories(sRootDirectory)

            'Process the file location arrays from the Search Directories sub
            Dim sFormattedDate
            sFormattedDate = Now().Year & CStr(Now().Month).PadLeft(2, "0") & CStr(Now().Day).PadLeft(2, "0")
            sFormattedDate = sFormattedDate & "." & CStr(Now().Hour).PadLeft(2, "0") & CStr(Now().Minute).PadLeft(2, "0")
            sFormattedDate = sFormattedDate & CStr(Now().Second).PadLeft(2, "0")

            Dim sTrimFileName, sTrimFileExt, sNewFileName
            For iCounter = 1 To iFileCount
                bValidHeader = True
                bValidFooter = True
                Try
                    sFileName = aFileNames(iCounter)
                    sTrimFileName = Left(sFileName, Len(sFileName) - InStr(StrReverse(sFileName), "."))
                    sTrimFileExt = Right(sFileName, InStr(StrReverse(sFileName), "."))
                    sNewFileName = sTrimFileName & "." & sFormattedDate & sTrimFileExt
                    sPath = aFilePaths(iCounter)
                    sFileData = GetFileData(sPath, sFileName, sFileType) 'function call
                    sMARSHACD = sPath.Replace(sRootDirectory & "\", "").Replace("\inbound\", "") 'The MARSHA code is the directory name

                    bArchiveToDW = CheckIfShouldBeArchivedToDW(sMARSHACD)
                    bLoadToMystique = CheckIfShouldBeLoaded(sMARSHACD)

                    If bLoadToMystique And bArchiveToDW Then 'Copy the file
                        Try
                            Kill(sDWArchiveDirectory & "\" & sNewFileName)
                        Catch ex As Exception
                        End Try
                        FileSystem.FileCopy(sPath & sFileName, sDWArchiveDirectory & "\" & sNewFileName)
                    ElseIf Not bLoadToMystique And bArchiveToDW Then 'Move the file
                        Try
                            Kill(sDWArchiveDirectory & "\" & sNewFileName)
                        Catch ex As Exception
                        End Try
                        FileSystem.Rename(sPath & sFileName, sDWArchiveDirectory & "\" & sNewFileName)
                    End If

                    If bLoadToMystique Then
                        If bValidHeader And bValidFooter Then 'both get set in GetFileData
                            Select Case sFileType
                                Case "PA"
                                    WriteToMQ(sMQMgrName, sPAQueueName, sFileData)
                                    Try
                                        Kill(sArchiveDirectory & "\" & sNewFileName)
                                    Catch ex As Exception
                                    End Try
                                    FileSystem.Rename(sPath & sFileName, sArchiveDirectory & "\" & sNewFileName)
                                Case "PS"
                                    WriteToMQ(sMQMgrName, sPSQueuename, sFileData)
                                    Try
                                        Kill(sArchiveDirectory & "\" & sNewFileName)
                                    Catch ex As Exception
                                    End Try
                                    FileSystem.Rename(sPath & sFileName, sArchiveDirectory & "\" & sNewFileName)
                            End Select
                        Else
                            MoveBadFile(sPath, sFileName)
                            If Not bValidHeader Then
                                WriteLog("Main.Bad Header in: " & sPath & sFileName)
                            ElseIf Not bValidFooter Then
                                WriteLog("Main.Bad Footer in: " & sPath & sFileName)
                            End If

                        End If
                    End If
                Catch e As Exception
                    If bInMQProcess Then
                        WriteLog("Main.MQFailure:" & e.ToString)
                    Else
                        WriteLog("Main.ProcessArray: " & e.ToString)
                    End If
                    Try
                        FileSystem.FileClose(sPath, sFileName)
                    Catch ex As Exception
                    End Try
                    MoveBadFile(sPath, sFileName)
                End Try
            Next iCounter

        Catch e As Exception
            WriteLog("FATAL Error: " & e.ToString)
        End Try
    End Sub
    Sub ReadParameters()
        'This sub reads the parameter from the PMSToMQ.xml file 
        'which govern how the process runs

        Dim iCounter As Int32
        Dim XMLDocObj As Object
        Dim oSkipDirs As Object
        Dim oLoadIntoMystiqueDirs As Object
        Dim oArchiveToDWDirs As Object
        Dim oArchiveToDW As Object
        XMLDocObj = CreateObject("microsoft.xmldom")
        XMLDocObj.async = False
        XMLDocObj.Load(".\PMSToMQ.xml")
        If XMLDocObj.parseError.errorCode = 0 Then
            'Set Variables
            sMQMgrName = XMLDocObj.documentElement.selectSingleNode("/PMS/QueueMgrName").Text
            sPAQueueName = XMLDocObj.documentElement.selectSingleNode("/PMS/PAQueueName").Text
            sPSQueuename = XMLDocObj.documentElement.selectSingleNode("/PMS/PSQueueName").Text()
            sRootDirectory = XMLDocObj.documentElement.selectSingleNode("/PMS/RootDirectory").Text()
            sArchiveDirectory = XMLDocObj.documentElement.selectSingleNode("/PMS/ArchiveDirectory").Text()
            sBadDirectory = XMLDocObj.documentElement.selectSingleNode("/PMS/BadDirectory").Text()
            sLogDirectory = XMLDocObj.documentElement.selectSingleNode("/PMS/LogDirectory").Text()
            iPosFileType = XMLDocObj.documentElement.selectSingleNode("/PMS/FileTypeIndPos").Text()
            oSkipDirs = XMLDocObj.documentElement.selectNodes("/PMS/DirectoryList/skip_dir")

            ReDim aSkipDirs(oSkipDirs.length)
            For iCounter = 0 To oSkipDirs.length - 1
                aSkipDirs(iCounter) = UCase(oSkipDirs.item(iCounter).Text())
            Next

            oLoadIntoMystiqueDirs = XMLDocObj.documentElement.selectNodes("/PMS/DirectoriesToLoadToMystique/directory")
            ReDim aLoadIntoMystique(oLoadIntoMystiqueDirs.Length)
            For iCounter = 0 To oLoadIntoMystiqueDirs.length - 1
                aLoadIntoMystique(iCounter) = UCase(oLoadIntoMystiqueDirs.item(iCounter).Text())
            Next

            oArchiveToDWDirs = XMLDocObj.documentElement.selectNodes("/PMS/DirectoriesToArchiveToDW/directory")
            ReDim aArchiveToDW(oArchiveToDWDirs.Length)
            For iCounter = 0 To oArchiveToDWDirs.length - 1
                aArchiveToDW(iCounter) = UCase(oArchiveToDWDirs.item(iCounter).Text())
            Next


            sDWArchiveDirectory = XMLDocObj.documentElement.selectSingleNode("/PMS/DWArchiveDirectory").Text()
        End If
        oSkipDirs = Nothing
        oLoadIntoMystiqueDirs = Nothing
        oArchiveToDWDirs = Nothing
        XMLDocObj = Nothing
    End Sub
    Sub WriteToMQ(ByVal sMQMgrName As String, ByVal sQueueName As String, ByVal sMessage As String)
        'This subroutine writes a message to the MQSeries server
        ' SMQMgrName = QueueManager Name
        ' sQueueName = Destination Queue 
        ' sMessage = Contents of a PA/PS file

        'Following statement is for ease of debugging
        bInMQProcess = True

        Dim mqSession As MQSession                '* MQSession instance
        Dim mqQMGr As MQQueueManager
        Dim mqPutMsgOpts As MQPutMessageOptions
        Dim mqQueue As MQQueue
        Dim mqMQMsg As MQMessage

        mqSession = New MQSession
        'Connect to the QueueManager
        mqQMGr = mqSession.AccessQueueManager(sMQMgrName)
        'Connect to the Destination Queue
        mqQueue = mqQMGr.AccessQueue(sQueueName, MQOO_OUTPUT + MQOO_FAIL_IF_QUIESCING)     '* open queue for output but not if MQM stopping
        ' Get a message object
        mqMQMsg = mqSession.AccessMessage()
        ' write the File data to the message object
        mqMQMsg.WriteBytes(sMessage)

        mqMQMsg.Format = MQFMT_STRING
        mqPutMsgOpts = mqSession.AccessPutMessageOptions()
        'Write the message to the destination queue
        mqQueue.Put(mqMQMsg, mqPutMsgOpts)
        'Disconnect from the queue manager
        mqQMGr.Disconnect()
        ' kill the objects
        mqPutMsgOpts = Nothing
        mqQueue = Nothing
        mqMQMsg = Nothing
        mqSession = Nothing
        mqQMGr = Nothing

        bInMQProcess = False
    End Sub
    Function SearchDirectories(ByVal sRootDirectory)
        'This sub searches a directory structure for input files
        ' sRootDirectory = Root of PMS FTP hierarchy
        Dim oFSO As Object
        Dim oRootFolder As Object
        Dim oFolderColl As Object
        Dim oFileColl As Object
        Dim oFile As Object
        Dim sFileName As String
        Dim bExcludeFolder As Boolean
        Dim iCounter As Int32


        oFSO = CreateObject("Scripting.FileSystemObject")
        oRootFolder = oFSO.GetFolder(sRootDirectory)
        'Get  list of folders in the root directory
        For Each oFolderColl In oRootFolder.SubFolders
            'now go to the input folder

            'If folder appears in the exclusion list, ignore
            bExcludeFolder = False
            For iCounter = 0 To aSkipDirs.Length - 1
                If UCase(oFolderColl.Name()) = aSkipDirs(iCounter) Then
                    bExcludeFolder = True
                End If
            Next


            If Not bExcludeFolder Then
                Try
                    oFileColl = oFSO.GetFolder(oFolderColl.Path & "\inbound").Files
                    ' Loop through the files in the input folder
                    For Each oFile In oFileColl
                        'Increase the size of the array by one, then store the 
                        'file name in the last element
                        Try
                            iFileCount = iFileCount + 1
                            ReDim Preserve aFileNames(iFileCount)
                            ReDim Preserve aFilePaths(iFileCount)
                            aFileNames(iFileCount) = oFile.Name
                            aFilePaths(iFileCount) = oFolderColl.Path & "\inbound\"
                        Catch e As Exception
                            WriteLog(oFile.Name & "|" & e.ToString)
                        End Try
                    Next
                Catch e As Exception
                    WriteLog(oFolderColl.Name & "|" & e.ToString)
                End Try
            End If
        Next
            'Destroy objects
            oFile = Nothing
            oFileColl = Nothing
            oFolderColl = Nothing
            oRootFolder = Nothing
            oFSO = Nothing
    End Function
    Sub MoveBadFile(ByVal myPath As String, ByVal myFileName As String)
        'This subroutine does two things:
        '1. It moves a rejected file to another directory
        '2. It writes the name of the file to a log file.

        Dim oFSO As Object
        Dim oWriteFile As Object
        Dim sWriteFileName As String
        Dim sFullFileName As String
        Dim sNewName As String

        Try
            sFullFileName = myPath & myFileName

            'Delete instances of same file name in the destination directory
            sNewName = sBadDirectory & "\" & myFileName
            Try
                Kill(sNewName)
            Catch ex As Exception
            End Try

            'Move File to another directory
            FileSystem.Rename(sFullFileName, sNewName)

            'Write to a log
            oFSO = CreateObject("Scripting.FileSystemObject")
            sWriteFileName = sLogDirectory & "\PMSLog - " & Month(Now()) & "-" & Day(Now()) & "-" & Year(Now()) & ".csv"
            oWriteFile = oFSO.OpenTextFile(sWriteFileName, 8, True, 0)
            oWriteFile.Writeline(ConvertIntoCSV("File Failed on " & Now()) & ConvertIntoCSV(sFullFileName))
            oWriteFile.Close()

        Catch e As Exception
            WriteLog(e.ToString)
        End Try

        'garbage disposal
        oFSO = Nothing
        oWriteFile = Nothing
    End Sub

    Function ConvertIntoCSV(ByVal sString)
        ConvertIntoCSV = """" & sString & ""","
    End Function
    Function LoadIntoMystique(ByVal sMARSHAcd)

    End Function

    Sub WriteLog(ByVal sLogMessage As String)
        'This sub writes a message to the log file. (.\PMSToMQ.txt)
        Dim iFile As Integer
        iFile = FileSystem.FreeFile()
        FileSystem.FileOpen(iFile, sLogFileName, OpenMode.Append, OpenAccess.Write, OpenShare.LockReadWrite)
        FileSystem.PrintLine(iFile, "=============================================")
        FileSystem.PrintLine(iFile, System.DateTime.Now & " :: " & sLogMessage)
        FileSystem.FileClose(iFile)
    End Sub
    Function GetFileData(ByVal sFilePath As String, ByVal sFileName As String, ByRef sFileType As String) As String
        'This function reads an input file and returns the File Type and contents
        '  sFilePath = Path to the file with a trailing "\"
        '  sFileName = File Name
        '  sFileType = Type of input file (PA/PS)  (ByRef)
        Dim sFileData As String
        Dim sPMSFileData As String
        Dim sLastLine As String
        Dim aPMSHeader() As String
        Dim srInputFile As StreamReader
        Dim bHaveADataRecord As Boolean

        Dim isHeader As Boolean
        isHeader = True

        'Open the file for reading
        srInputFile = New StreamReader(sFilePath & sFileName)
        'Get the first line
        sFileData = srInputFile.ReadLine
        'Loop through the data in the file
        While Not sFileData Is Nothing And bValidHeader
            sLastLine = sFileData
            If isHeader Then
                ' The file type is stored in the header record, record it for later use
                aPMSHeader = sFileData.Split("|")
                sFileType = aPMSHeader(iPosFileType)
                'Check header
                If sFileType = "PA" Or sFileType = "PS" Then
                    bValidHeader = True
                Else
                    bValidHeader = False
                End If
                ' Modify the header to include the file name.  This is required by the PMS BusSrvs for auditing
                sPMSFileData = sFileData & sFileName & "|" & vbCrLf
                isHeader = False
            Else
                sPMSFileData = sPMSFileData & sFileData
                '*****************************************************************************************
                '* This Section is required to account for the embedded line feeds that                  *
                '* the PMS systems will be sending in the PMS comments Fields in both the PA and PS files*
                '*****************************************************************************************
                If Left(sFileData, 1) = "D" Then
                    bHaveADataRecord = True
                Else
                    bHaveADataRecord = False
                End If
                While bHaveADataRecord And Right(sPMSFileData, 1) <> "|"
                    sPMSFileData = sPMSFileData & " " & srInputFile.ReadLine
                End While
                '********************************************************************
                '* End Line feed correction.
                '********************************************************************
                sPMSFileData = sPMSFileData & vbCrLf
            End If
            'Read the next record
            sFileData = srInputFile.ReadLine
        End While

        'Close the file
        srInputFile.Close()

        'Check the footer
        If sLastLine.Equals("Z|") Then
            bValidFooter = True
        Else
            bValidFooter = False
        End If

        'kill the objects
        srInputFile = Nothing

        'return the file's contents
        GetFileData = sPMSFileData

    End Function
    Function CheckIfShouldBeLoaded(ByVal sMARSHACD As String)
        'This function compares the MARSHA code of the received file against
        'the list of MARSHA codes to be loaded into mystique listed in the XML parameter
        'file
        Dim i As Int32
        Dim bReturn As Boolean
        bReturn = False
        For i = 0 To aLoadIntoMystique.Length - 1
            If UCase(sMARSHACD) = UCase(aLoadIntoMystique(i)) Then
                bReturn = True
            End If
        Next

        CheckIfShouldBeLoaded = bReturn
    End Function
    Function CheckIfShouldBeArchivedToDW(ByVal sMARSHACD As String)
        'This function compares the MARSHA code of the received file against
        'the list of MARSHA codes to be archived to the DW in the XML parameter
        'file
        Dim i As Int32
        Dim bReturn As Boolean
        bReturn = False
        For i = 0 To aArchiveToDW.Length - 1
            If UCase(sMARSHACD) = UCase(aArchiveToDW(i)) Then
                bReturn = True
            End If
        Next

        CheckIfShouldBeArchivedToDW = bReturn
    End Function


End Module
